<?php

    require_once "IYWSLibrary/IYWSInformation.php";
    require_once "IYWSLibrary/IYWSDesign.php";
    require_once "IYWSLibrary/IYWSUser.php";
    require_once "IYWSLibrary/IYWSDirectory.php"
?>